<?php
session_start();
if($_SESSION['auth'] == 'false') {
    header("Location: auth.php");
}
header("Content-Type: text/html; charset=utf-8");
ini_set("display_errors", 1);
error_reporting(1);
$servername = "localhost";
$username = "dbUser";
$password = "321";
$dbname = "shop";

// create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// check connection
if ($conn->connect_error) {
  die("Connection failerd: ".$conn->connect_error);
}
$sql = "SELECT * FROM products";
$products = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lactis | Admin producte</title>
    <link href="../css/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/app.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark mx-0">
        <div class="container-fluid">
            <a href="admin.php" class="navbar-brand">Admin</a>
            <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav">                        
                    <li class="nav-item">
                        <a href="admin_users.php" aria-current="page" class="nav-link">Utilizatori</a>
                    </li>                  
                    <li class="nav-item">
                        <a href="#" class="nav-link">Produse</a>
                    </li>
                    <li class="nav-item">
                        <a href="../index.php" target="_blank" class="nav-link">Site</a>
                    </li>
                </ul>
            </div>
            <a href="auth.php?logout" class="nav-link text-white">Iesire</a>
        </div>
    </nav>
    <div class="container-fluid">
        <h1 class="text-center">
            Produse
            <a href="products_management.php?op=add&prod=0">
                <img src="../img/add.png" class="task" alt="addImg">
            </a>
        </h1>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col"></th>
                    <th scope="col">Produs</th>
                    <th scope="col">Categorie</th>
                    <th scope="col">Descriere</th>
                    <th scope="col">Actiuni</th>
                </tr>
            </thead>
            <tbody class="table-group-divider">
                <?php 
                    $counter = 1;
                    while($product = $products->fetch_assoc()) {
                ?>
                <tr>
                    <th scope="row"><?=$counter++;?></th>
                    <td><?=$product['title'];?></td>
                    <td><?=$product['category'];?></td>
                    <td>Masa neta: <?=$product['masa'];?> <?=$product['unitate']?></td>
                    <td>
                        <a href="products_management.php?op=delete&prod=<?=$product['id'];?>">
                            <img src="../img/delete.png" class="task" alt="crestic">
                        </a>
                        <a href="products_management.php?op=update&prod=<?=$product['id'];?>">
                            <img src="../img/refresh.png" class="task" alt="crestic">
                        </a>
                    </td>
                </tr>
                <?php 
                    }
                ?>
            </tbody>
        </table>
    </div>
    <?php 
        $conn->close();
    ?>
</body>
</html>