<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Lactis | Noutati</title>
    <link href="../css/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/app.css" rel="stylesheet">
  </head>
  <body>
    <nav class="navbar navbar-expand-lg bg-light">
        <div class="container-fluid">
            <a href="#" class="navbar-brand">
                <img src="../img/logo.png" alt="logo" width="300px" height="auto">
            </a>
            <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a href="../index.php" class="nav-link">Acasa</a>
                    </li>
                    <li class="nav-item">
                        <a href="products.php" class="nav-link">Produse</a>
                    </li>
                    <li class="nav-item">
                        <a href="about.php" class="nav-link">Despre noi</a>
                    </li>
                    <li class="nav-item">
                        <a href="news.php" class="nav-link active">Noutati</a>
                    </li>
                    <li class="nav-item">
                        <a href="contacts.php" class="nav-link">Contacte</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <script src="../js/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
  </body>
</html>
