<?php
session_start();
if(isset($_GET["logout"])) {
    $_SESSION["username"] = "";
    $_SESSION["username"] = "";
} elseif (isset($_SESSION["auth"]) && $_SESSION["auth"] == "true") {
    header("location: admin.php");
}
$_SESSION["auth"] = "false";
$message = "";
$message_class = "d-none";
if(isset($_POST["username"]) && isset($_POST["password"]) ){
    $user_name = strip_tags($_POST["username"]);
    $user_password = strip_tags($_POST["password"]);
    ini_set("display_errors", 1);
    error_reporting(E_ALL);

    $servername = "localhost";
    $username = "dbUser";
    $password = "321";
    $dbname = "shop";

    // create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // check connection
    if ($conn->connect_error) {
        die("Connection failerd: ".$conn->connect_error);
    }
    $sql = "SELECT count(id) as user_exist FROM users WHERE username = '$user_name' AND password='$user_password'";
    $users = $conn->query($sql);
    $user = $users->fetch_assoc();
    if($user["user_exist"] == 1) {
        $_SESSION["auth"] = 'true';
        $_SESSION["username"] = $user_name;
        $_SESSION["password"] = $user_password;
        header("Location: admin.php");
    } else {
        $message = 'Logare incorecta!';
        $message_class = "";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Latics | Autentificare</title>
    <link href="../css/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container-fluid">
        <h1 class="text-center mt-5">Intrare</h1>
        <div class="row">
            <form action="auth.php" method="POST">
                <div class="col-6 offset-3">
                    <div class="mb-3">
                        <label for="login" class="form-label">Login</label>
                        <input type="text" name="username" class="form-control" id="login" placeholder="Login" required autocomplete="off">
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Parola</label>
                        <input type="password" name="password" class="form-control" id="password" placeholder="Introduceti parola" required autocomplete="off">
                    </div>
                    <input type="submit" name="auth_form" value="Autentificare" class="btn btn-primary">
                </div>
            </form>
        </div>
        <div class="row mt-3">
            <div class="col-6 offset-3 alert alert-danger <?=$message_class;?>" role="alert">
                <?=$message;?>
            </div>
        </div>
    </div>

    <?php 
        $conn->close();
    ?>
    <script src="../js/js/bootstrap.bundle.min.js"></script>
</body>
</html>