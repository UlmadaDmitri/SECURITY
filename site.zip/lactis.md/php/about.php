<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Lactis | Despre noi</title>
    <link href="../css/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/app.css" rel="stylesheet">
  </head>
  <body>
    <nav class="navbar navbar-expand-lg bg-light">
        <div class="container-fluid">
            <a href="#" class="navbar-brand">
                <img src="../img/logo.png" alt="logo" width="300px" height="auto">
            </a>
            <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a href="../index.php" class="nav-link">Acasa</a>
                    </li>
                    <li class="nav-item">
                        <a href="products.php" class="nav-link">Produse</a>
                    </li>
                    <li class="nav-item">
                        <a href="about.php" class="nav-link active">Despre noi</a>
                    </li>
                    <li class="nav-item">
                        <a href="news.php" class="nav-link">Noutati</a>
                    </li>
                    <li class="nav-item">
                        <a href="contacts.php" class="nav-link">Contacte</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container-fluid">
        <h1>Despre noi</h1>
        <p>Biografia Societăţii pe Acţiuni LACTIS numără 68 de ani, dacă ne referim la data deschiderii primei secţii de unt. Iar în 1956 a fost deschisă Fabrica de Brânzeturi din Râşcani cu secţie de lapte de consum, casein şi unt. Prima partidă de caşcaval a fost fabricată la data de 23 noiembrie 1969, dată considerată zi de naştere a Fabricii de Brînzeturi din Râşcani. S.A. Lactis este una dintre cela mai vechi întreprinderi de industrializare şi comercializare a laptelui.</p>
        <p>La momentul actual colectivul numără 240 de angajaţi, care produc un sortiment larg de caşcavaluri tari, semitari, topite şi afumate. Pe lângă produsele lactate integrale (lapte pasteurizat, chefir, smântână, frişcă, unt, brânză proaspătă), din anul 2012 s-a valorificat linia de produse îmbogăţite cu bifidobacteri - bio : chefir de 2,5 % şi biosmântână de 15 %.</p>
        <p>În total la momentul actual Lactis produce 17 tipuri de caşcavaluri şi brânzeturi.</p>
        <p>Pentru a avea acces la sursele de materie primă calitativă, S.A.Lactis a deschis circa 90 de puncte de colectare a laptelui în 86 sate din 7 raioane ale Republicii. Majoritatea din ele sunt dotate cu utilaj frigorific, precum și cu laboratoare – expres pentru verificarea calităţii materiei prime.</p>
        <p>Lansată pe piaţa Republicii Moldova, compania Lactis şi-a propus drept scop principal ridicarea nivelului de consum al produselor lactate prezentând consumatorului o înaltă calitate şi variat asortiment. S.A.Lactis îşi lărgeşte în mod sistematic gama de produse, poziţionate în diferite segmente pe piaţă. Se efectuiază procesul permanent de modernizare a utilajului tehnologic.</p>
        <p>Pe parcursul anilor, Compania Lactis s-a bucurat de numeroase premii, medalii şi diplome. Unele dintre meritele noastre în domeniul calităţii sînt:</p>
        <ul>
            <li>Premiu Mare “Mercuriul de aur”</li>
            <li>Premiul de gr.2 “Medalia de argint” pentru cea mai bună marcă comercială a anului 2004 şi 2006</li>
            <li>Premiul de stat pentru calitate şi competitivitate</li>
            <li>Diplomă de onoare “Cel mai bun contribuabil a anului 2010”</li>
            <li>Medalia de argint pentru cea mai bună marcă comercială a anului 2010</li>
            <li>Premiul Mare “Mercuriul de Aur” pentru cea mai bună marcă comercială a anului 2012 “Responsabil Social”.</li>
        </ul>
    </div>
    <script src="../js/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
  </body>
</html>
