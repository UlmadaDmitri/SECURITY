<?php 
ini_set("display_errors", 1);
error_reporting(1);
$servername = "localhost";
$username = "dbUser";
$password = "321";
$dbname = "shop";

// create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// check connection
if ($conn->connect_error) {
  die("Connection failerd: ".$conn->connect_error);
}
$sql = "SELECT * FROM products order by category asc";
$products = $conn->query($sql);
$categories = [
    'cascava_topit' => [
        'title' => 'Cascval topit',
        'products' => []
    ],
    'lapte' => [
        'title' => 'Lapte',
        'products' => []
    ],
    'brinza' => [
        'title' => 'Brinza',
        'products' => []
    ],
    'smintina' => [
        'title' => 'Smantana',
        'products' => []
    ],
    'unt' => [
        'title' => 'Unt',
        'products' => []
    ],
    'chefir' => [
        'title' => 'Chefir',
        'products' => []
    ],
    'cascaval_tare' => [
        'title' => 'Cascaval tare',
        'products' => []
    ],
    'alte_brinzeturi' => [
        'title' => 'Alte branzzeturi',
        'products' => []
    ]
];
while($product = $products->fetch_assoc()){
    foreach($categories as $key => &$category) {
        if(strcmp($product['category'], $key) == 0) {
            $category['products'][] = $product;
        }
    }
}
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Lactis | Produse</title>
    <link href="../css/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/app.css" rel="stylesheet">
  </head>
  <body>
    <nav class="navbar navbar-expand-lg bg-light">
        <div class="container-fluid">
            <a href="#" class="navbar-brand">
                <img src="../img/logo.png" alt="logo" width="300px" height="auto">
            </a>
            <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a href="../index.php" class="nav-link">Acasa</a>
                    </li>
                    <li class="nav-item">
                        <a href="poducts.php" class="nav-link active">Produse</a>
                    </li>
                    <li class="nav-item">
                        <a href="about.php" class="nav-link">Despre noi</a>
                    </li>
                    <li class="nav-item">
                        <a href="news.php" class="nav-link">Noutati</a>
                    </li>
                    <li class="nav-item">
                        <a href="contacts.php" class="nav-link">Contacte</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container-fluid">
        <div class="row">
            <h1>Produse</h1>
            <?php 
            foreach($categories as $key => $category) {
                echo "
                    <h4 class='text-center'>{$category['title']}</h4>
                    <div class='d-flex flex-wrap'>
                ";
                foreach($category['products'] as $pr) { ?>
                    <div class="card" style="width: 18rem;">
                        <img src="..." class="card-img-top" alt="...">
                        <div class="card-body">
                            <p class="card-text"><?=$pr['title'];?> <?=$pr['masa'];?> <?=$pr['unitate'];?></p>
                        </div>
                    </div>
                <?php }
                echo "</div>";
                }
            ?>
        </div>
    </div>
    <?php 
        $conn->close();
    ?>
    <script src="../js/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
  </body>
</html>
