<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Lactis | Contacte</title>
    <link href="../css/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/app.css" rel="stylesheet">
  </head>
  <body>
    <nav class="navbar navbar-expand-lg bg-light">
        <div class="container-fluid">
            <a href="#" class="navbar-brand">
                <img src="../img/logo.png" alt="logo" width="300px" height="auto">
            </a>
            <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a href="../index.php" class="nav-link">Acasa</a>
                    </li>
                    <li class="nav-item">
                        <a href="products.php" class="nav-link">Produse</a>
                    </li>
                    <li class="nav-item">
                        <a href="about.php" class="nav-link">Despre noi</a>
                    </li>
                    <li class="nav-item">
                        <a href="news.php" class="nav-link">Noutati</a>
                    </li>
                    <li class="nav-item">
                        <a href="contacts.php" class="nav-link active">Contacte</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container-fluid">
        <div class="row">
            <h1>Contacte</h1>
            <div class="col border-end">
                <p>or. Râșcani, str. Komarov 73, MD-5600</p>
                <p>025-628-644</p>
                <p>025-623-551</p>
                <p>025-628-554</p>
            </div>
            <div class="col">
                <h2>PROGRAM DE LUCRU</h2>
                <p>Luni - Vineri: 09.00 - 18.00</p>
                <p>Sâmbăta: 10.00 - 14.00</p>
                <p>Duminica: Zi libera</p>
            </div>
        </div>
    </div>
    <div id="contacts"></div>
    <script src="../js/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
  </body>
</html>
