<?php
$surname;
$name;
$password;
$username;
$userId;
$role;
$message_class;
$message;
$function;
$btn_title;
$removed;
if(strcmp($role, "user") === 0) {
    $user_role = 'checked';
    $admin_role = "";
} else {
    $user_role="";
    $admin_role="checked";
}
?>
<form action="users.php" method="POST">
    <input type="hidden" name="user" value="<?=$userId;?>">
    <div class="mb-3 row">
        <label for="surname" class="col-sm-2 col-form-label">Nume</label>
        <div class="col-sm-10">
            <input type="text" name="surname" class="form-control" id="surname" value="<?=$surname;?>">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="name" class="col-sm-2 col-form-label">Prenume</label>
        <div class="col-sm-10">
            <input type="text" name="name" class="form-control" id="name" value="<?=$name;?>">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="username" class="col-sm-2 col-form-label">Username</label>
        <div class="col-sm-10">
            <input type="text" name="username" class="form-control" id="username" value="<?=$username;?>">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="password" class="col-sm-2 col-form-label">Parola</label>
        <div class="col-sm-10">
            <input type="text" name="password" class="form-control" id="password" value="<?=$password;?>">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="name" class="col-sm-2 col-form-label">Rol</label>
        <div class="col-sm-10">
            <div class="form-check">
                <input type="radio" name="role" id="flexRadioDefault1" class="form-check-input" <?=$user_role;?> value="user">
                <label for="flexRadioDefault1">User</label>
            </div>
            <div class="form-check">
                <input type="radio" name="role" id="flexRadioDefault2" class="form-check-input" <?=$user_role;?> value="admin">
                <label for="flexRadioDefault2">Admin</label>
            </div>
        </div>  
    </div>
    <div class="mb-3 row">
        <div class="col-4 offset-8">
            <input type="submit" name="<?=$function;?>" value="<?=$btn_title;?>" class="btn btn-primary float-right <?=$removed;?>">
        </div>
    </div>
</form>

<div class="alert alert-<?=$message_class;?>" role="alert">
    <?=$message;?>
</div>