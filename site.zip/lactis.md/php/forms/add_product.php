<?php
$product_id;
$product_title;
$selected_category;
$selected_unit;
$masa;
$categories = [
    "cascaval_topit" => "Cascaval topit",
    "lapte" => "Lapte",
    "brinza" => "Branza de vaca",
    "smintina" => "Smantana",
    "unt" => "Unt si spreduri",
    "chefir" => "Chefir",
    "cascaval_tare" => "Cascavaluri tari",
    "alte_brinzeturi" => "Alte branzeturi"
];
$units = ["g","kg", "l"];
$message_class;
$message;
$function;
$btn_title;
$removed;
?>
<form action="products_management.php" method="POST">
    <input type="hidden" name="prod" value=<?=$product_id;?>>

    <div class="mb-3 row">
        <label for="product_title" class="col-sm-2 col-form-label">Produs</label>
        <div class="col-sm-10">
            <textarea name="product_title" class="form-control" id="product_title" rows="3"><?=$product_title;?></textarea>
        </div>
    </div>
    
    <div class="mb-3 row">
        <label for="category" class="col-sm-2 col-form-label">Categorie</label>
        <div class="col-sm-10">
            <select name="category" id="category" class="form-select">
                <option value="-1">Alegeti categoria</option>
                <?php
                foreach($categories as $key => $category) {
                    if(strcmp($selected_category, $key) == 0) {
                        echo "<option value='$key' selected>$category</option>";
                    } else {
                        echo "<option value='$key'>$category</option>";
                    }
                }
                ?>
            </select>
        </div>
    </div>

    <div class="mb-3 row">
        <label for="masa" class="col-sm-2 col-form-label">Masa</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="masa" name="masa" value="<?=$masa;?>">
        </div>
    </div>

    <div class="mb-3 row">
        <label for="unit" class="col-sm-2 col-form-label">Unitate</label>
        <div class="col-sm-10">
            <select name="unit" id="unit" aria-label="Default select example" class="form-select">
                <option value="-1">Alegeti unitate</option>
                <?php
                foreach($units as $unit) {
                    if($selected_unit === $unit) {
                        echo "<option value='$unit' selected>$unit</option>";
                    } else {
                        echo "<option value='$unit'>$unit</option>";
                    }
                }
                ?>
            </select>
        </div>
    </div>

    <div class="mb-3 row">
        <div class="col-4 offset-8">
            <input type="submit" name="<?=$function;?>" value="<?=$btn_title;?>" class="btn btn-primary float-right <?=$removed;?>">
        </div>
    </div>
</form>


<div class="alert alert-<?=$message_class;?>" role="alert">
    <?=$message;?>
</div>