<?php
session_start();
ini_set("display_errors", 1);
error_reporting(E_ALL);

$servername = "localhost";
$username = "dbUser";
$password = "321";
$dbname = "shop";

// create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// check connection
if ($conn->connect_error) {
  die("Connection failerd: ".$conn->connect_error);
}

$operation="";
$title = $message_class = $message = "";

if(isset($_POST["update_user_form"])) {
  $userId=$_POST["user"];
  $surname=$_POST["surname"];
  $name=$_POST["name"];
  $role=$_POST["role"];
  $password=$_POST["password"];
  $username=$_POST["username"];
  $title="Actualizarea utilizatorului";
  $function="update_user_form";
  $btn_title="Actualizeaza";
  $removed="";
  $sql="UPDATE users SET surname='$surname', name='$name', role='$role', username='$username', password='$password' WHERE id=$userId";
  if($conn->query($sql) ==  true) {
    $message_class = "success";
    $message = "Utilizatorul a fost actualizat";
  } else {
    $message_class="danger";
    $message=mysqli_error($conn);
  }
}elseif(isset($_POST["add_user_form"])){
  $userId = $_POST['user'];
  $surname =$_POST['surname'];
  $name =$_POST['name'];
  $role=$_POST['role'];
  $password=$_POST['password'];
  $username=$_POST['username'];
  $title="Crearea utilizatorului";
  $function="add_user_form";
  $sql= sprintf("INSERT INTO users(surname, name, role, password, username) VALUES('%s', '%s', '%s', '%s', '%s')", $surname, $name, $role, $password, $username);
  $btn_title="Adauga";
  $removed="";
  if($conn->query($sql)) {
    $message_class = "success";
    $message = "Utilizatorul a fost creat";
  } else {
    $message_class="danger";
    $message=mysqli_error($conn);
  }
} elseif(isset($_POST['delete_user_form'])){
  $userId = $_POST['user'];
  $surname =$_POST['surname'];
  $name =$_POST['name'];
  $role=$_POST['role'];
  $password=$_POST['password'];
  $username=$_POST['username'];
  $title="Stergerea utilizatorului";
  $function="delete_user_form";
  $sql= sprintf("DELETE FROM users WHERE id=%s", $userId);
  $btn_title="Sterge";
  $removed="";
  if($conn->query($sql)) {
    $message_class = "success";
    $message = "Utilizatorul a fost sters";
  } else {
    $message_class="danger";
    $message=mysqli_error($conn);
  }
} 
 else {
  $userId = $_GET["user"];
}

if(isset($_GET["op"])) {
  switch($_GET["op"]) {
    case "add":
      $message_class="d-none";
      $message="";
      $surname="";
      $name="";
      $role="user";
      $password="";
      $username="";
      $title="Crearea utilizatorului";
      $function="add_user_form";
      $btn_title="Adauga";
      $removed="";
      break;
    case "delete":
      $sql = "SELECT * FROM users WHERE id = $userId";
      $query = $conn->query($sql);
      $user = $query->fetch_assoc();
      $message_class = "d-none";
      $message = "";
      $surname=$user['surname'];
      $name = $user['name'];
      $role = $user['role'];
      $password = $user['password'];
      $username = $user['username'];
      $function="delete_user_form";
      $title = "Eliminarea utilizatorului";
      $btn_title = "Sterge";
      break;
    case "update":
      $sql = "SELECT * FROM users WHERE id = " . $userId;
      $query = $conn->query($sql);
      $user = $query->fetch_assoc();
      $message_class = "d-none";
      $message = "";
      $surname=$user['surname'];
      $name = $user['name'];
      $role = $user['role'];
      $password = $user['password'];
      $username = $user['username'];
      $function="update_user_form";
      $title = "Actualizarea utilizatorului";
      $btn_title = "Actualizeaza";
  }
}

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin | Users</title>
    <link href="../css/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/app.css" rel="stylesheet">
  </head>
  <body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark mx-0">
        <div class="container-fluid">
            <a href="admin.php" class="navbar-brand">Admin</a>
            <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a href="admin_users.php" aria-current="page" class="nav-link">Utilizatori</a>
                    </li>
                    <li class="nav-item">
                        <a href="admin_products.php" class="nav-link">Produse</a>
                    </li>
                    <li class="nav-item">
                        <a href="../index.php" target="_blank" class="nav-link">Site</a>
                    </li>
                </ul>
            </div>
            <a href="auth.php?logout" class="nav-link text-white">Iesire</a>
        </div>
    </nav>
    <div class="container-fluid mt-2">
      <h1 class="text-center">Utilizatori. <?=$title;?></h1>
      <?php
        require("forms/add_user.php");
      ?>
    </div>
    <?php
        $conn->close();
    ?>
    <script src="../js/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
