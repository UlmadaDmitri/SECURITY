<?php
session_start();
ini_set("display_errors", 1);
error_reporting(E_ALL);

$servername = "localhost";
$username = "dbUser";
$password = "321";
$dbname = "shop";

// create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// check connection
if ($conn->connect_error) {
  die("Connection failerd: ".$conn->connect_error);
}

$operation="";
$title = $message_class = $message = "";

if(isset($_POST["update_prod_form"])) {
  $product_id=$_POST["prod"];
  $product_title=$_POST["product_title"];
  $selected_category=$_POST["category"];
  $selected_unit=$_POST["unit"];
  $masa=$_POST["masa"];
  $title="Actualizarea produsului";
  $function="update_prod_form";
  $btn_title="Actualizeaza";
  $removed="";
  $sql="UPDATE products SET title='$product_title', category='$selected_category', masa='$masa', unitate='$selected_unit' WHERE id=$product_id";
  if($conn->query($sql) ==  true) {
    $message_class = "success";
    $message = "Produsul a fost actualizat";
  } else {
    $message_class="danger";
    $message=mysqli_error($conn);
  }
}elseif(isset($_POST["add_prod_form"])){
    $product_id=$_POST["prod"];
    $product_title=$_POST["product_title"];
    $selected_category=$_POST["category"];
    $selected_unit=$_POST["unit"];
    $masa=$_POST["masa"];
    $title="Adaugarea produsului";
    $function="add_prod_form";
    $btn_title="Adauga";
    $removed="";
    $sql="INSERT INTO products(title, category, masa, unitate) VALUES('$product_title', '$selected_category', '$masa', '$selected_unit')";
    if($conn->query($sql)) {
      $message_class = "success";
      $message = "Produsul a fost adaugat";
    } else {
      $message_class="danger";
      $message=mysqli_error($conn);
    }
} elseif(isset($_POST['delete_prod_form'])){
    $product_id=$_POST["prod"];
    $product_title=$_POST["product_title"];
    $selected_category=$_POST["category"];
    $selected_unit=$_POST["unit"];
    $masa=$_POST["masa"];
    $title="Stergerea produsului";
    $function="delete_prod_form";
    $btn_title="Sterge";
    $removed="";
    $sql="DELETE FROM products WHERE id=$product_id";
    if($conn->query($sql) ==  true) {
      $message_class = "success";
      $message = "Produsul a fost sters";
    } else {
      $message_class="danger";
      $message=mysqli_error($conn);
    }
}
else {
 $product_id = $_GET["prod"];
}

if(isset($_GET["op"])) {
  switch($_GET["op"]) {
    case "add":
      $message_class="d-none";
      $message="";
      $product_title="";
      $selected_category="";
      $selected_unit="";
      $masa="";
      $title="Adaugarea utilizatorului";
      $function="add_prod_form";
      $btn_title="Adauga";
      $removed="";
      break;
    case "delete":
      $sql = "SELECT * FROM products WHERE id = $product_id";
      $query = $conn->query($sql);
      $product = $query->fetch_assoc();
      $message_class = "d-none";
      $message = "";
      $product_title=$product['title'];
      $selected_category = $product['category'];
      $selected_unit = $product['unitate'];
      $masa = $product['masa'];
      $function="delete_prod_form";
      $title = "Eliminarea produsului";
      $btn_title = "Sterge";
      break;
    case "update":
      $sql = "SELECT * FROM products WHERE id = $product_id";
      $query = $conn->query($sql);
      $product = $query->fetch_assoc();
      $message_class = "d-none";
      $message = "";
      $product_title=$product['title'];
      $selected_category = $product['category'];
      $selected_unit = $product['unitate'];
      $masa = $product['masa'];
      $function="update_prod_form";
      $title = "Actualizarea produsului";
      $btn_title = "Actualizeaza";
  }
}

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin | Products management</title>
    <link href="../css/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/app.css" rel="stylesheet">
  </head>
  <body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark mx-0">
        <div class="container-fluid">
            <a href="admin.php" class="navbar-brand">Admin</a>
            <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a href="admin_users.php" aria-current="page" class="nav-link">Utilizatori</a>
                    </li>
                    <li class="nav-item">
                        <a href="admin_products.php" class="nav-link">Produse</a>
                    </li>
                    <li class="nav-item">
                        <a href="../index.php" target="_blank" class="nav-link">Site</a>
                    </li>
                </ul>
            </div>
            <a href="auth.php?logout" class="nav-link text-white">Iesire</a>
        </div>
    </nav>
    <div class="container-fluid mt-2">
      <h1 class="text-center">Produse. <?=$title;?></h1>
      <?php
        require("forms/add_product.php");
      ?>
    </div>
    <?php
        $conn->close();
    ?>
    <script src="../js/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
